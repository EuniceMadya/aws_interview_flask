public class test_time{
  public static void (String []args){
    long start = System.nanoTime();
    addString ();
    long end = System.nanoTime();
    long duration = (end - start);
    System.out.println("time for string is" + duration);
  }


  public static String addString(){
    System.out.println("isss" + "isss");
  }

  public static String addString_pf(){
    System.out.printf("isss" , "isss");
  }

  public static String addString_buffer(){
    System.out.printf("isss" , "isss");
  }
}
