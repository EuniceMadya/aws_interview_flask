import UIKit

var str = "Hello, playground"

var sum = 0
for index in 1...100{
    sum += index
}
print(sum)
